default_app_config = "slick_reporting.apps.ReportAppConfig"

VERSION = (1, 3, 1)

__version__ = "1.3.1"
