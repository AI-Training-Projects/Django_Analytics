.. _reference:

Reference
===========

Below are links to the reference documentation for the various components of the Django slick reporting .

.. toctree::
   :maxdepth: 2
   :caption: Components:

   settings
   view_options
   computation_field
   report_generator



