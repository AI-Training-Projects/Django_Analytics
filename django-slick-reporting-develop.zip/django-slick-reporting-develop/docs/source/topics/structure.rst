.. _structure:

================
Rows and columns
================

It's natural to think of a report as a form of tabular data, with rows and columns.

We willexplore the ways one can create the rows and column of a report.

a simple example
